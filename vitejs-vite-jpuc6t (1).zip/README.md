# Görev 1: Alışveriş Sitesi - Kategoriler

Çalıştığın yerde uzun zamandır kendini işlerine vermiştin. Ara vermeden çalıştığın için de sırtın ağrımaya başladı.
Çalışma saatlerin de belli bir rutine oturmaya başlayınca tekrar spora başladın.

Spor hocan kendine yeni bir iş kurmaya çalışıyor. Yurt dışı alışveriş sitelerindeki ürünler satacak. Senin de yazılımcı olduğunu öğrenince sana bazı sorular sordu. Sen de bunları nasıl yapabileceğini merak ettin.

Kendisi bir alışveriş sitesi yapacak. ürünlerini burada sergileyecek ve amazon gibi siteler üzerinden de satacak.

ilk olarak ürün kategorilerini bir API'den almayı denemek istedin.
Araştırdın ve bir Fake API buldun. Bunun üzerinde çalışarak bir şeyler yapabilirsin.

\`SideBar\` component'i yüklendiğinde https://fakestoreapi.com/products/categories adresinden kategorileri alıp, CategoryList component'ine prop olarak gönderelim ve [ekrandaki](https://i.ibb.co/W3CRd1F/s6d3-task1-design.png) gibi görünmesini sağlayalım.

- İpucu: \`useEffect\` hook'unun 3 farklı kullanımı var. Bunlardan uygun olanı kullanabilirsin.
