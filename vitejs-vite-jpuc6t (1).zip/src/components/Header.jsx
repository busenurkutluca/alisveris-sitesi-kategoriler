function Header(props) {
  const { searchText, handleSearch } = props;

  return (
    <>
      <header>
        <h1>WiStore Products</h1>
      </header>
    </>
  );
}

export default Header;
