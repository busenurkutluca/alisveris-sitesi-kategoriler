import { useEffect, useState } from 'react';
import CategoryList from './CategoryList';
import axios from 'axios';

export default function SideBar() {
  /* ADIM 1: Bir state tanımlayabilirsin */

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    axios
      .get('https://fakestoreapi.com/products/categories')
      .then((res) => {
        setCategories(res.data);
      })
      .catch((err) => {
        console.warn(err);
      });
  }, []);

  /* ADIM 2: kategorileri buradan alıp CategoryList'e yollayabilirsin: https://fakestoreapi.com/products/categories */

  return (
    <>
      <div className="side-container">
        <h2>Categories</h2>
        <CategoryList categories={categories} />
      </div>
    </>
  );
}
